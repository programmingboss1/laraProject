<?php $__env->startSection('body'); ?>
	<h1 style="text-align: center;">All Job List<h1><hr>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<table class="table">
			<thead class="thead-dark">
				<tr>
					<td scope="col">Company Name</td>
					<td scope="col" scope="col" scope="col">Job Tilte</td>
					<td scope="col" scope="col">Vacancy</td>
					<td scope="col">Job Type</td>
					<td scope="col">Education Requirement</td>
					<td scope="col">Job Location</td>
					<td scope="col">Job Category</td>
					<td scope="col">Experience</td>
					<td scope="col">Salary</td>
					<td scope="col">Job Description</td>
					<td scope="col">Action</td>
				</tr>
			</thead>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($value->companyName); ?></td>
				<td><?php echo e($value->jobTitle); ?></td>
				<td><?php echo e($value->vacancy); ?></td>
				<td><?php echo e($value->jobType); ?></td>
				<td><?php echo e($value->educationalRequirement); ?></td>
				<td><?php echo e($value->jobLocation); ?></td>
				<td><?php echo e($value->jobCatagory); ?></td>
				<td><?php echo e($value->experience); ?></td>
				<td><?php echo e($value->salary); ?></td>
				<td><?php echo e($value->description); ?></td>
				<td><a href=""><button>Edit</button></a>&nbsp;<a href=""><button>Delete</button></a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laraProject\resources\views/all_job.blade.php ENDPATH**/ ?>