<?php $__env->startSection('body'); ?>
	<div class="page">
		
		<div class="left">
			<h1><i class="fa fa-bars" aria-hidden="true"></i>Dasboard</h1>
			<ul>
				<li><a href="/employerInfo">> Personal Information</a></li>
				<li><a href="/employerCompany">> Company Information</a></li>
				<li><a href="/new_job_post">> New Job Post</a></li>
				<li><a href="/all_job">> All Job Post</a></li>
				<li><a href="/">> Log Out</a></li>
			</ul>
		</div>
		<div class="right">
			<img src="employer.JPG" style="width:200px;height:250px;"><br>
			<h1><b>Name:Abc</b></h1>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laraProject\resources\views/employerHomepage.blade.php ENDPATH**/ ?>